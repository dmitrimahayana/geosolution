<?php

//$query= $this->login_history_model->cek_dual_login($this->session->userdata('ID_USER'));
//foreach($query as $row){
//    echo $row->ID_HISTORY.' '.$row->ID_USER.' '.$row->IP_ADDRESS.' '.$row->TIME.' '.$row->IS_ONLINE.'<br/>';
//}
?>
Cek your email to validate login
